// ==================== 桌宠性格 ====================
const SYSTEM_PROMPT = `你是一个可爱的桌面宠物，名字叫大肥鱼。你说话简短、俏皮，每句话不超过30个字。你偶尔会用颜文字，比如 (๑•̀ㅂ•́)و✧ 或 (›´ω`‹ )。你不写长篇大论，像一个活泼的小朋友。`;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // CORS 预检
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }

    // 聊天接口
    if (url.pathname === "/api/chat" && request.method === "POST") {
      return handleChat(request, env);
    }

    return new Response(JSON.stringify({ error: "Not Found" }), {
      status: 404,
      headers: { "Content-Type": "application/json", ...corsHeaders() },
    });
  },
};

// ==================== CORS 头 ====================
function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };
}

// ==================== 聊天处理 ====================
async function handleChat(request, env) {
  try {
    const { message, history = [] } = await request.json();

    if (!message) {
      return new Response(JSON.stringify({ error: "message 不能为空" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders() },
      });
    }

    // 只保留最近 8 轮（16 条消息）
    const trimmedHistory = history.slice(-16);

    const messages = [
      { role: "system", content: SYSTEM_PROMPT },
      ...trimmedHistory,
      { role: "user", content: message },
    ];

    const response = await env.AI.run(
      "@cf/deepseek-ai/deepseek-r1-distill-qwen-32b",
      {
        messages,
        max_tokens: 256,
        temperature: 0.8,
        stream: true,
      }
    );

    // 流式返回，附带 CORS
    const { readable, writable } = new TransformStream();
    response.pipeTo(writable);

    return new Response(readable, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        ...corsHeaders(),
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders() },
    });
  }
}